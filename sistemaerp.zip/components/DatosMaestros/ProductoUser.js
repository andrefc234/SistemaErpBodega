import React,{useState,useEffect,useRef} from 'react'
import {Form,Card,Table} from 'react-bootstrap'
import axios from 'axios'
import Image from 'next/image'
import Router from 'next/router'
export default function ProductosUser(user)  {
    const [pta, setpta] = useState([])
    const [cliente, setcliente] = useState([])
  const fetchptda = async (d) => {
        var result = [];
      const resp = await fetch(`http://${process.env.IP}:5000/api/v1/productos`)
       const dtajson = await resp.json()
       const crdta = dtajson.data
        return setpta(crdta);  
      }
  const fetchcliente = async (d) => {
        var result = [];
      const resp = await fetch(`http://${process.env.IP}:5000/api/v1/cliente`)
       const dtajson = await resp.json()
       const crdta = dtajson.data
        return setcliente(crdta);  
      }
      useEffect(() => {
        fetchptda()
        fetchcliente()
      }, [])
      return(<>
      <Form  >
      <div><Table striped bordered hover responsive><thead>
        <tr>  
          <th>Nombre Producto</th>
          <th>Codigo de Barras</th>
          <th>Descripcion</th>
          <th>Imagen</th>
        </tr>
      </thead>
      <tbody>
        {pta.map(d => {
          console.log(d.img)
            return(
            <tr key='1'>
              <td key={d.nombre}>{d.nombre}</td>
              <td key={d.codigoBarras}>{d.codigoBarras}</td>
              <td key={d.descripcion}>{d.descripcion}</td>
              <td className='text-center'> <img
        src={d.img}
        alt="Picture of the author"
        width={60}
        height={233}
      />   </td>
            </tr>
        )
      })}
        </tbody>
        </Table>
        </div>
       
       </Form>
      </>)
  }
