import React from 'react'
import CreatePDF from '../components/TestComponents/createpdf'
export default function pdf() {
  return (
    <CreatePDF/>
  )
}
